package il.co.xsites.developertest.pizza;

import il.co.xsites.developertest.pizza.model.PizzaMenu;

import java.util.List;

public interface PizzaHandler {

	List<PizzaMenu> getPizzaMenu();

	List<PizzaMenu> getPizzaMenu(String menuName, Integer minPrice, Integer maxPrice);

	PizzaMenu getPizza(Long id);
}
