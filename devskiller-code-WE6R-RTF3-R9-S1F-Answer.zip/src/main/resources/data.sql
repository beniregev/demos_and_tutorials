INSERT INTO pizza_menu (name, price, creation_time, last_update_time)
VALUES
  ('Hawaiian', 4.99, now(), now()),
  ('Margherita', 0.59, now(), now()),
  ('Sicilian', 2.99, now(), now()),
  ('Neapolitan', 3.99, now(), now()),
  ('Cheesy Crust', 7.99, now(), now()),
  ('Greek', 4.99, now(), now()),
  ('New York Thin Crust', 4.99, now(), now()),
  ('Calzone', 7.99, now(), now()),
  ('Veggie', 6.99, now(), now()),
  ('Meat Lover', 9.99, now(), now());